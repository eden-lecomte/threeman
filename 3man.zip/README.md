<h1>Three man drinking app</h1>
<p>This app is about drinking and playing 3 man!.</p>

<h2>Features</h2>

<# Finished>
- ...

<# TODO>
- Welcome screen
- Rules page
- Game page
